#!/bin/bash
# World Happiness Report Dashboard – lokaler Start (macOS / Linux)
# Einmalig: chmod +x start.sh

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Virtuelle Umgebung anlegen (nur beim ersten Start)
if [ ! -d ".venv" ]; then
    echo "→ Erstelle virtuelle Umgebung ..."
    python3 -m venv .venv
fi

# Pakete installieren / aktualisieren
echo "→ Installiere Abhängigkeiten ..."
.venv/bin/pip install -q --upgrade pip
.venv/bin/pip install -q -r requirements.txt

echo ""
echo "✓ Dashboard startet auf http://localhost:8050"
echo "  Strg+C zum Beenden"
echo ""
.venv/bin/python app.py

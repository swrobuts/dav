@echo off
:: World Happiness Report Dashboard – lokaler Start (Windows)
cd /d "%~dp0"

:: Virtuelle Umgebung anlegen (nur beim ersten Start)
if not exist ".venv\" (
    echo Erstelle virtuelle Umgebung ...
    python -m venv .venv
)

:: Pakete installieren
echo Installiere Abhaengigkeiten ...
.venv\Scripts\pip install -q --upgrade pip
.venv\Scripts\pip install -q -r requirements.txt

echo.
echo Dashboard startet auf http://localhost:8050
echo Strg+C zum Beenden
echo.
.venv\Scripts\python app.py

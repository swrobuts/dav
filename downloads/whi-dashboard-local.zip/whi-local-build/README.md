# World Happiness Report – Lokale Installation

Interaktives Daten-Dashboard auf Basis von Plotly Dash (Python).  
Datenquelle: World Happiness Report 2015–2025 (Gallup World Poll).

## Voraussetzungen

- Python 3.9 oder neuer ([python.org](https://www.python.org/downloads/))
- Terminal / Eingabeaufforderung

Python-Version prüfen:
```
python3 --version
```

## Start

### macOS / Linux

```bash
chmod +x start.sh   # einmalig
./start.sh
```

### Windows

Doppelklick auf `start.bat` oder im Terminal:
```
start.bat
```

Das Script legt beim ersten Start automatisch eine virtuelle Umgebung an und installiert alle Abhängigkeiten (~1–2 Minuten).

Anschließend ist das Dashboard erreichbar unter:  
**http://localhost:8050**

## Manuell (ohne Start-Script)

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

## Dateien

| Datei | Inhalt |
|-------|--------|
| `app.py` | Dash-Anwendung (Layout + Callbacks) |
| `data_loader.py` | Datenlader (liest lokale CSV) |
| `whr_combined_2015_2025.csv` | Datensatz (~1.500 Zeilen, 150+ Länder) |
| `assets/style.css` | Stylesheet |
| `assets/card-maximize.js` | Vollbild-Funktion für Diagrammkacheln |
| `requirements.txt` | Python-Abhängigkeiten |

## Abhängigkeiten

```
dash==2.14.2
dash-bootstrap-components==1.5.0
plotly==5.18.0
pandas==2.1.4
scipy==1.11.4
```

## Hinweise

- Das Dashboard läuft ausschließlich lokal auf dem eigenen Rechner.
- Keine Internetverbindung nach dem ersten Start erforderlich.
- Zum Beenden: Strg+C im Terminal.

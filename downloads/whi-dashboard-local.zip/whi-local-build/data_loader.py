"""
World Happiness Report – Lokaler CSV-Datenlader
Ersetzt den Supabase-Loader für die Offline-Installation.
Liest whr_combined_2015_2025.csv aus dem gleichen Verzeichnis.
"""

import pandas as pd
from functools import lru_cache
from pathlib import Path

# CSV liegt im selben Verzeichnis wie dieses Script
CSV_PATH = Path(__file__).parent / "whr_combined_2015_2025.csv"

# Spalten-Mapping: CSV → app.py erwartet diese Namen
COLUMN_MAP = {
    "Country":          "country_name",
    "Year":             "year",
    "Region":           "region_name",
    "Happiness Rank":   "happiness_rank",
    "Happiness Score":  "happiness_score",
    "GDP":              "gdp",
    "Social Support":   "social_support",
    "Life Expectancy":  "life_expectancy",
    "Freedom":          "freedom",
    "Generosity":       "generosity",
    "Corruption":       "corruption",
}

ISO_CODES = {
    "Afghanistan": "AFG", "Albania": "ALB", "Algeria": "DZA", "Argentina": "ARG",
    "Armenia": "ARM", "Australia": "AUS", "Austria": "AUT", "Azerbaijan": "AZE",
    "Bahrain": "BHR", "Bangladesh": "BGD", "Belarus": "BLR", "Belgium": "BEL",
    "Benin": "BEN", "Bhutan": "BTN", "Bolivia": "BOL", "Bosnia and Herzegovina": "BIH",
    "Botswana": "BWA", "Brazil": "BRA", "Bulgaria": "BGR", "Burkina Faso": "BFA",
    "Burundi": "BDI", "Cambodia": "KHM", "Cameroon": "CMR", "Canada": "CAN",
    "Central African Republic": "CAF", "Chad": "TCD", "Chile": "CHL", "China": "CHN",
    "Colombia": "COL", "Comoros": "COM", "Congo (Brazzaville)": "COG",
    "Congo (Kinshasa)": "COD", "Costa Rica": "CRI", "Croatia": "HRV", "Cuba": "CUB",
    "Cyprus": "CYP", "Czech Republic": "CZE", "Denmark": "DNK", "Djibouti": "DJI",
    "Dominican Republic": "DOM", "Ecuador": "ECU", "Egypt": "EGY", "El Salvador": "SLV",
    "Estonia": "EST", "Eswatini": "SWZ", "Ethiopia": "ETH", "Finland": "FIN",
    "France": "FRA", "Gabon": "GAB", "Gambia": "GMB", "Georgia": "GEO",
    "Germany": "DEU", "Ghana": "GHA", "Greece": "GRC", "Guatemala": "GTM",
    "Guinea": "GIN", "Haiti": "HTI", "Honduras": "HND", "Hong Kong": "HKG",
    "Hungary": "HUN", "Iceland": "ISL", "India": "IND", "Indonesia": "IDN",
    "Iran": "IRN", "Iraq": "IRQ", "Ireland": "IRL", "Israel": "ISR",
    "Italy": "ITA", "Ivory Coast": "CIV", "Jamaica": "JAM", "Japan": "JPN",
    "Jordan": "JOR", "Kazakhstan": "KAZ", "Kenya": "KEN", "Kosovo": "XKX",
    "Kuwait": "KWT", "Kyrgyzstan": "KGZ", "Laos": "LAO", "Latvia": "LVA",
    "Lebanon": "LBN", "Lesotho": "LSO", "Liberia": "LBR", "Libya": "LBY",
    "Lithuania": "LTU", "Luxembourg": "LUX", "Macedonia": "MKD", "Madagascar": "MDG",
    "Malawi": "MWI", "Malaysia": "MYS", "Maldives": "MDV", "Mali": "MLI",
    "Malta": "MLT", "Mauritania": "MRT", "Mauritius": "MUS", "Mexico": "MEX",
    "Moldova": "MDA", "Mongolia": "MNG", "Montenegro": "MNE", "Morocco": "MAR",
    "Mozambique": "MOZ", "Myanmar": "MMR", "Namibia": "NAM", "Nepal": "NPL",
    "Netherlands": "NLD", "New Zealand": "NZL", "Nicaragua": "NIC", "Niger": "NER",
    "Nigeria": "NGA", "North Cyprus": "CYP", "Norway": "NOR", "Oman": "OMN",
    "Pakistan": "PAK", "Palestinian Territories": "PSE", "Panama": "PAN",
    "Paraguay": "PRY", "Peru": "PER", "Philippines": "PHL", "Poland": "POL",
    "Portugal": "PRT", "Qatar": "QAT", "Romania": "ROU", "Russia": "RUS",
    "Rwanda": "RWA", "Saudi Arabia": "SAU", "Senegal": "SEN", "Serbia": "SRB",
    "Sierra Leone": "SLE", "Singapore": "SGP", "Slovakia": "SVK", "Slovenia": "SVN",
    "Somalia": "SOM", "South Africa": "ZAF", "South Korea": "KOR", "South Sudan": "SSD",
    "Spain": "ESP", "Sri Lanka": "LKA", "Sudan": "SDN", "Suriname": "SUR",
    "Sweden": "SWE", "Switzerland": "CHE", "Syria": "SYR", "Taiwan": "TWN",
    "Tajikistan": "TJK", "Tanzania": "TZA", "Thailand": "THA", "Togo": "TGO",
    "Trinidad and Tobago": "TTO", "Tunisia": "TUN", "Turkey": "TUR",
    "Turkmenistan": "TKM", "Uganda": "UGA", "Ukraine": "UKR",
    "United Arab Emirates": "ARE", "United Kingdom": "GBR", "United States": "USA",
    "Uruguay": "URY", "Uzbekistan": "UZB", "Venezuela": "VEN", "Vietnam": "VNM",
    "Yemen": "YEM", "Zambia": "ZMB", "Zimbabwe": "ZWE",
}


@lru_cache(maxsize=1)
def load_happiness_data() -> pd.DataFrame:
    """Lädt und cached die vollständigen WHR-Daten aus der lokalen CSV."""
    df = pd.read_csv(CSV_PATH)

    # Nur bekannte Spalten umbenennen (fehlende Spalten werden ignoriert)
    rename = {k: v for k, v in COLUMN_MAP.items() if k in df.columns}
    df = df.rename(columns=rename)

    # Datentypen sichern
    df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
    df["happiness_rank"] = pd.to_numeric(df["happiness_rank"], errors="coerce")
    df["happiness_score"] = pd.to_numeric(df["happiness_score"], errors="coerce")
    for col in ["gdp", "social_support", "life_expectancy", "freedom", "generosity", "corruption"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # ISO-3-Codes für Choropleth-Karte
    df["iso_alpha"] = df["country_name"].map(ISO_CODES)

    return df.sort_values(["year", "happiness_rank"]).reset_index(drop=True)


def get_available_years() -> list:
    """Sortierte Liste der verfügbaren Jahre."""
    df = load_happiness_data()
    return sorted(df["year"].dropna().unique().tolist())


def get_available_regions() -> list:
    """Sortierte Liste der verfügbaren Regionen."""
    df = load_happiness_data()
    return sorted(df["region_name"].dropna().unique().tolist())


def clear_cache():
    """Cache leeren (z.B. nach Datei-Änderung)."""
    load_happiness_data.cache_clear()


if __name__ == "__main__":
    print("Lade lokale Daten ...")
    df = load_happiness_data()
    print(f"✓ {len(df)} Datensätze geladen")
    print(f"✓ Jahre: {get_available_years()}")
    print(f"✓ Regionen: {len(get_available_regions())}")
    print(f"\nBeispiel:\n{df.head()}")
